<?php

$name = "Gabby";

echo "<p>My name is $name</P>";

$string1 = "<p>This is the first part";


$string2 = "of a sentence</p>";

echo $string1." ".$string2;


$myNumber = 45;


$calculation = $myNumber * 31/ 97  * 4;
  
echo "The answer of the calculation is   ".  $calculation;

$myBool = true;

echo "<p>This Statement true?".$myBool."</p>";

$variableName = "name";
echo $$variableName;




?>