<?php
	if (isset($_POST["submit"])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$message = $_POST['message'];
		$human = intval($_POST['human']);
		$from = 'Demo Contact Form'; 
		$to = 'example@bootstrapbay.com'; 
		$subject = 'Message from Contact Demo ';
		
		$body = "From: $name\n E-Mail: $email\n Message:\n $message";

		// Check if name has been entered
		if (!$_POST['name']) {
			$errName = 'Please enter your name';
		}
		
		// Check if email has been entered and is valid
		if (!$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
			$errEmail = 'Please enter a valid email address';
		}
		
		//Check if message has been entered
		if (!$_POST['message']) {
			$errMessage = 'Please enter your message';
		}
		//Check if simple anti-bot test is correct
		if ($human !== 5) {
			$errHuman = 'Your anti-spam is incorrect';
		}

// If there are no errors, send the email
if (!$errName && !$errEmail && !$errMessage && !$errHuman) {
	if (mail ($to, $subject, $body, $from)) {
		$result='<div class="alert alert-success">Thank You! I will be in touch</div>';
	} else {
		$result='<div class="alert alert-danger">Sorry there was an error sending your message. Please try again later</div>';
	}
}
	}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Contact <Form></Form></title>
  </head>
  <body>

    <div class="container">
    <h1>Contact Gabriel!</h1>

    <div id="error"></div>



    <form method="post">
        <div class="form-group">
          <label for="email">Email address</label>
          
          
          <input type="email" class="form-control" id="email" name="email" placeholder=" Enter email">
          <small class="text-muted">We'll never share your email with anyone
        </div>

         <div class="form-group">
            <label for="subject">Subject</label>
           
            <input tyep="Subject" class="form-control" id="subject" name="subject" placeholder="Password">

            
         </div>
        


        <div class="form-group">
          <label for="exampleFormControlTextarea1">You are free to ask any question</label>
          <textarea class="form-control" id="content" name="content" rows="3"></textarea>
        </div>



        <button type="submit" class="btn-danger">Submit</button>
      </form> 

      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script type="text/javascript">
     
     $("form").submit(function(e) {
       
      e.preventDefault();

      var erro="";

      if ($("#email").val() == "") {

error += "<p>The email field is required.</p>";
  
}



      if ($("#subject").val() == "") {

      error += "<p>The subject field is required.</p>";
        
      }


      $("#error").html(error)

      
      if ($("#content").val() == "") {

error += "<p>The content field is required.</p>";
  
}
   

   if (error != ""){

      $("#error").html('<div class="alert alert-danger"role="alert"><p><strong>There were error(s) in your form:</strong></p>' + error + '</div>');

      
   } else{

     $("form").unblind("submit").submit();

   }
    

     });



    </script>
  </body>
</html>