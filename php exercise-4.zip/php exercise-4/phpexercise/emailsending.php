<?php

$emailTo = "igabriel.manasseh@gmail.com";

$subject = "I am a living Testimony!";

$body = "I think I'm Great Man"

$headers = "From: amsung@samsung.com";

if (email($emailTo, $subject, $body, $headers)) {

 echo "The email was sent successfully";




} else {

 echo "The email could not be sent.";


}


?>